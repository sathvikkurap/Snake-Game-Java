# Snake-Game
I built this watching a tutorial and used my own graphics.

I am a 6th grader who is interested in Java and I want to take my coding skills to the next level.
